# ShadowFox TV Fast Task Killer v2

One-click Android / Android TV / Fire TV cleanup app.

## v2 changes
- Main screen now has one large **CLEAN NOW** button.
- No root check or root prompt at startup.
- Automatically scans user-installed apps.
- On rooted devices, CLEAN NOW uses root for true `am force-stop`.
- On non-root devices, CLEAN NOW uses Android's standard background-process cleanup request where supported.
- Keeps this app, Android System UI, Settings, and common TV launchers protected.
- Remote / D-pad friendly interface.
- Version 2.0.0.

## Important Android limitation
Modern Android does not allow an ordinary third-party app to silently force-stop arbitrary other apps.
Therefore:
- **Rooted device:** true force-stop cleanup.
- **Non-root device:** best-effort standard Android background cleanup; behavior is limited by Android version/vendor.

The app intentionally does not claim the non-root fallback is equivalent to a true force-stop.
