# ShadowFox TV Fast Task Killer

A custom Android / Android TV / Fire TV task killer designed for rooted devices.

## What this build does

- ShadowFox TV branding and supplied logo
- Android mobile launcher support
- Android TV / Google TV / Fire TV launcher support
- D-pad / remote friendly controls
- Lists user-installed applications
- Select individual apps
- Select all user apps
- Force-stop selected apps using root (`su` + `am force-stop`)
- Protects this app, Android System UI, and common TV launchers from the Kill All action
- GitHub Actions builds an APK entirely in the cloud

## Root behavior

Modern Android does not allow an ordinary third-party app to force-stop arbitrary other apps.
This build therefore uses root access for the actual force-stop operation. When your root manager
asks whether to grant root access to **ShadowFox TV Fast Task Killer**, approve it.

## Build from an Android phone using GitHub

1. Create a new empty GitHub repository.
2. Upload the contents of this ZIP to the repository root.
3. Open the repository's **Actions** tab.
4. Select **Build ShadowFox Task Killer APK**.
5. Tap **Run workflow**.
6. When it finishes, open the completed workflow.
7. Download the **ShadowFox-TV-Fast-Task-Killer** artifact.
8. Unzip that artifact and install `app-debug.apk` on your Android TV box.

## About visnkmr/backgroundappslist

The public `visnkmr/backgroundappslist` repository was checked before this project was created.
Its current repository tree contains documentation/marker `.md` files and GitHub workflow files,
but not the Android application source project (no Gradle Android source tree is present), and
no explicit open-source license file is present in the repository tree.

For that reason this project is an original implementation rather than a copy or modification
of proprietary/unpublished app source.

## Package

`ca.shadowfoxtv.taskkiller`

## Version

1.0.0
