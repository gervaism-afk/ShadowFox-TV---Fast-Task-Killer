package ca.shadowfoxtv.taskkiller;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final List<AppItem> apps = new ArrayList<>();
    private final Set<String> protectedPackages = new HashSet<>();

    private LinearLayout appList;
    private TextView rootStatus;
    private TextView summaryText;
    private boolean rootAvailable = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        appList = findViewById(R.id.appList);
        rootStatus = findViewById(R.id.rootStatus);
        summaryText = findViewById(R.id.summaryText);

        protectedPackages.add(getPackageName());
        protectedPackages.add("com.android.systemui");
        protectedPackages.add("com.google.android.tvlauncher");
        protectedPackages.add("com.google.android.apps.tv.launcherx");
        protectedPackages.add("com.google.android.tv.remote.service");

        Button scan = findViewById(R.id.scanButton);
        Button selectAll = findViewById(R.id.selectAllButton);
        Button clear = findViewById(R.id.clearButton);
        Button killSelected = findViewById(R.id.killSelectedButton);
        Button killAll = findViewById(R.id.killAllButton);

        scan.setOnClickListener(v -> scanApps());
        selectAll.setOnClickListener(v -> setAllChecked(true));
        clear.setOnClickListener(v -> setAllChecked(false));
        killSelected.setOnClickListener(v -> confirmKill(false));
        killAll.setOnClickListener(v -> confirmKill(true));

        checkRoot();
        scanApps();
    }

    private void checkRoot() {
        executor.execute(() -> {
            rootAvailable = canUseSu();
            runOnUiThread(() -> {
                if (rootAvailable) {
                    rootStatus.setText("ROOT: READY");
                    rootStatus.setTextColor(Color.rgb(54, 226, 122));
                } else {
                    rootStatus.setText("ROOT: NOT AVAILABLE");
                    rootStatus.setTextColor(Color.rgb(255, 86, 86));
                }
            });
        });
    }

    private boolean canUseSu() {
        Process p = null;
        try {
            p = Runtime.getRuntime().exec(new String[]{"su", "-c", "id"});
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = r.readLine();
            int code = p.waitFor();
            return code == 0 && line != null && line.contains("uid=0");
        } catch (Exception e) {
            return false;
        } finally {
            if (p != null) p.destroy();
        }
    }

    private void scanApps() {
        summaryText.setText("Scanning installed user apps…");
        executor.execute(() -> {
            List<AppItem> found = new ArrayList<>();
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> installed = pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0));

            for (ApplicationInfo info : installed) {
                boolean system = (info.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                boolean updatedSystem = (info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;

                // Default behavior: show user-installed apps only.
                if (system && !updatedSystem) continue;
                if (protectedPackages.contains(info.packageName)) continue;

                String label = pm.getApplicationLabel(info).toString();
                found.add(new AppItem(label, info.packageName));
            }

            Collections.sort(found, Comparator.comparing(a -> a.label.toLowerCase()));
            runOnUiThread(() -> render(found));
        });
    }

    private void render(List<AppItem> found) {
        apps.clear();
        apps.addAll(found);
        appList.removeAllViews();

        int pad = dp(12);
        for (AppItem item : apps) {
            CheckBox cb = new CheckBox(this);
            cb.setText(item.label + "\n" + item.packageName);
            cb.setTextColor(Color.WHITE);
            cb.setTextSize(15f);
            cb.setPadding(pad, dp(8), pad, dp(8));
            cb.setTag(item.packageName);
            cb.setFocusable(true);
            cb.setButtonTintList(android.content.res.ColorStateList.valueOf(Color.rgb(16,156,255)));
            appList.addView(cb, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));
        }

        summaryText.setText(apps.size() + " user apps found. Select apps or use KILL ALL USER APPS.");
        if (appList.getChildCount() > 0) appList.getChildAt(0).requestFocus();
    }

    private void setAllChecked(boolean checked) {
        for (int i = 0; i < appList.getChildCount(); i++) {
            View v = appList.getChildAt(i);
            if (v instanceof CheckBox) ((CheckBox) v).setChecked(checked);
        }
        summaryText.setText(checked ? "All user apps selected." : "Selection cleared.");
    }

    private List<String> selectedPackages(boolean all) {
        List<String> out = new ArrayList<>();
        for (int i = 0; i < appList.getChildCount(); i++) {
            View v = appList.getChildAt(i);
            if (v instanceof CheckBox) {
                CheckBox cb = (CheckBox) v;
                if (all || cb.isChecked()) {
                    String pkg = (String) cb.getTag();
                    if (pkg != null && !protectedPackages.contains(pkg)) out.add(pkg);
                }
            }
        }
        return out;
    }

    private void confirmKill(boolean all) {
        List<String> targets = selectedPackages(all);
        if (targets.isEmpty()) {
            Toast.makeText(this, "No apps selected.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!rootAvailable) {
            new AlertDialog.Builder(this)
                    .setTitle("Root access required")
                    .setMessage("Android does not allow a normal app to force-stop other apps. On your rooted Android TV box, grant this app root access when prompted.")
                    .setPositiveButton("CHECK ROOT", (d, w) -> checkRoot())
                    .setNegativeButton("CANCEL", null)
                    .show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle(all ? "Kill all user apps?" : "Kill selected apps?")
                .setMessage("Force-stop " + targets.size() + " app(s)? The launcher, Android System UI and this task killer are protected.")
                .setPositiveButton("KILL NOW", (d, w) -> killTargets(targets))
                .setNegativeButton("CANCEL", null)
                .show();
    }

    private void killTargets(List<String> targets) {
        summaryText.setText("Closing " + targets.size() + " app(s)…");
        executor.execute(() -> {
            int success = 0;
            List<String> failed = new ArrayList<>();

            for (String pkg : targets) {
                if (protectedPackages.contains(pkg)) continue;
                try {
                    int code = runRootCommand("am force-stop " + shellQuote(pkg));
                    if (code == 0) success++;
                    else failed.add(pkg);
                } catch (Exception e) {
                    failed.add(pkg);
                }
            }

            final int ok = success;
            runOnUiThread(() -> {
                summaryText.setText("Closed " + ok + " of " + targets.size() + " app(s).");
                if (!failed.isEmpty()) {
                    Toast.makeText(this, failed.size() + " app(s) could not be closed.", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "Task cleanup complete.", Toast.LENGTH_SHORT).show();
                }
                setAllChecked(false);
            });
        });
    }

    private int runRootCommand(String command) throws Exception {
        Process p = Runtime.getRuntime().exec("su");
        try (DataOutputStream os = new DataOutputStream(p.getOutputStream())) {
            os.writeBytes(command + "\n");
            os.writeBytes("exit\n");
            os.flush();
        }
        return p.waitFor();
    }

    private String shellQuote(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }

    private int dp(int n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        executor.shutdown();
        super.onDestroy();
    }

    private static final class AppItem {
        final String label;
        final String packageName;

        AppItem(String label, String packageName) {
            this.label = label;
            this.packageName = packageName;
        }
    }
}
