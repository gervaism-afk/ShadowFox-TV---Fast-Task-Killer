package ca.shadowfoxtv.taskkiller;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final List<String> userPackages = new ArrayList<>();
    private final Set<String> protectedPackages = new HashSet<>();

    private TextView summaryText;
    private TextView modeText;
    private TextView appsCleanedText;
    private TextView ramRecoveredText;
    private TextView storageRecoveredText;
    private View resultCard;
    private Button cleanButton;
    private boolean cleaning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        summaryText = findViewById(R.id.summaryText);
        modeText = findViewById(R.id.modeText);
        appsCleanedText = findViewById(R.id.appsCleanedText);
        ramRecoveredText = findViewById(R.id.ramRecoveredText);
        storageRecoveredText = findViewById(R.id.storageRecoveredText);
        resultCard = findViewById(R.id.resultCard);
        cleanButton = findViewById(R.id.cleanButton);
        Button rescanButton = findViewById(R.id.rescanButton);

        protectedPackages.add(getPackageName());
        protectedPackages.add("com.android.systemui");
        protectedPackages.add("com.google.android.tvlauncher");
        protectedPackages.add("com.google.android.apps.tv.launcherx");
        protectedPackages.add("com.google.android.tv.remote.service");
        protectedPackages.add("com.android.settings");

        cleanButton.setOnClickListener(v -> cleanNow());
        rescanButton.setOnClickListener(v -> {
            resultCard.setVisibility(View.GONE);
            scanApps();
        });

        modeText.setText("AUTOMATIC MODE");
        scanApps();
        cleanButton.requestFocus();

        View root = findViewById(R.id.rootLayout);
        View header = findViewById(R.id.headerCard);
        View status = findViewById(R.id.statusCard);
        Animation intro = AnimationUtils.loadAnimation(this, R.anim.fade_scale_in);
        root.startAnimation(intro);
        header.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_scale_in));
        status.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_scale_in));
    }

    private void scanApps() {
        executor.execute(() -> {
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> installed = pm.getInstalledApplications(0);
            List<String> found = new ArrayList<>();

            for (ApplicationInfo info : installed) {
                boolean system = (info.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                boolean updatedSystem = (info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;

                if (system && !updatedSystem) continue;
                if (protectedPackages.contains(info.packageName)) continue;
                found.add(info.packageName);
            }

            runOnUiThread(() -> {
                userPackages.clear();
                userPackages.addAll(found);
                if (!cleaning) {
                    summaryText.setText(userPackages.size() + " user apps ready for cleanup");
                }
            });
        });
    }

    private void cleanNow() {
        if (cleaning) return;
        cleaning = true;
        cleanButton.setEnabled(false);
        cleanButton.setText("CLEANING…");
        resultCard.setVisibility(View.GONE);
        summaryText.setText("Cleaning background apps…");

        final List<String> targets = new ArrayList<>(userPackages);
        final long ramBefore = getAvailableRamBytes();
        final long storageBefore = getFreeStorageBytes();

        executor.execute(() -> {
            boolean root = hasRootWithoutInteractiveProbe();
            int appsCleaned = 0;

            if (root) {
                for (String pkg : targets) {
                    if (protectedPackages.contains(pkg)) continue;
                    try {
                        Process p = Runtime.getRuntime().exec(
                                new String[]{"su", "-c", "am force-stop " + shellQuote(pkg)});
                        if (p.waitFor() == 0) appsCleaned++;
                    } catch (Exception ignored) {}
                }

                // Safe one-click cache cleanup: trims application caches only.
                // Does not clear app data, logins, settings, downloads, or user files.
                try {
                    Process p = Runtime.getRuntime().exec(
                            new String[]{"su", "-c", "pm trim-caches 999G"});
                    p.waitFor();
                } catch (Exception ignored) {}

            } else {
                ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                if (am != null) {
                    for (String pkg : targets) {
                        if (protectedPackages.contains(pkg)) continue;
                        try {
                            am.killBackgroundProcesses(pkg);
                            appsCleaned++;
                        } catch (Exception ignored) {}
                    }
                }
            }

            // Android memory accounting settles asynchronously after processes are stopped.
            try {
                Thread.sleep(1200);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }

            final long ramAfter = getAvailableRamBytes();
            final long storageAfter = getFreeStorageBytes();
            final long ramRecovered = Math.max(0L, ramAfter - ramBefore);
            final long storageRecovered = Math.max(0L, storageAfter - storageBefore);
            final int cleanedCount = appsCleaned;
            final boolean usedRoot = root;

            runOnUiThread(() -> {
                cleaning = false;
                cleanButton.setEnabled(true);
                cleanButton.setText(R.string.clean_now);
                cleanButton.startAnimation(AnimationUtils.loadAnimation(this, R.anim.button_pop));

                if (usedRoot) {
                    modeText.setText("DEEP CLEAN MODE");
                    modeText.setTextColor(Color.rgb(54, 226, 122));
                } else {
                    modeText.setText("STANDARD CLEANUP MODE");
                    modeText.setTextColor(Color.rgb(175, 195, 216));
                }

                summaryText.setText("Cleanup complete");
                appsCleanedText.setText("Apps cleaned: " + cleanedCount);
                ramRecoveredText.setText("RAM recovered: " + formatMb(ramRecovered));
                storageRecoveredText.setText("Storage reclaimed: " + formatMb(storageRecovered));
                resultCard.setVisibility(View.VISIBLE);
                resultCard.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_scale_in));

                if (!usedRoot) {
                    Toast.makeText(
                            this,
                            "Storage cache cleanup requires root. Standard background cleanup was used.",
                            Toast.LENGTH_SHORT
                    ).show();
                }

                scanApps();
                cleanButton.requestFocus();
            });
        });
    }

    private long getAvailableRamBytes() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) return 0L;
        ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(info);
        return info.availMem;
    }

    private long getFreeStorageBytes() {
        try {
            StatFs stat = new StatFs(Environment.getDataDirectory().getAbsolutePath());
            return stat.getAvailableBytes();
        } catch (Exception e) {
            return 0L;
        }
    }

    private String formatMb(long bytes) {
        double mb = bytes / (1024.0 * 1024.0);
        if (mb < 0.05) return "0 MB";
        if (mb < 10.0) return String.format(java.util.Locale.US, "%.1f MB", mb);
        return String.format(java.util.Locale.US, "%.0f MB", mb);
    }

    private boolean hasRootWithoutInteractiveProbe() {
        String[] candidates = {
                "/system/bin/su",
                "/system/xbin/su",
                "/sbin/su",
                "/su/bin/su",
                "/data/adb/magisk/su"
        };

        boolean suExists = false;
        for (String p : candidates) {
            if (new java.io.File(p).exists()) {
                suExists = true;
                break;
            }
        }
        if (!suExists) return false;

        Process p = null;
        try {
            p = Runtime.getRuntime().exec(new String[]{"su", "-c", "id"});
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = r.readLine();
            int code = p.waitFor();
            return code == 0 && line != null && line.contains("uid=0");
        } catch (Exception e) {
            return false;
        } finally {
            if (p != null) p.destroy();
        }
    }

    private String shellQuote(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }

    @Override
    protected void onDestroy() {
        executor.shutdown();
        super.onDestroy();
    }
}
