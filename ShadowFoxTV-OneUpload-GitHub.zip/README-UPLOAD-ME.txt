# ShadowFox TV Fast Task Killer - One Upload Setup

Upload these TWO items to the root of your GitHub repository:

1. `ShadowFoxTV-FastTaskKiller-Project.zip`
2. the `.github` folder

GitHub Actions will unzip the Android project automatically and build the APK in the cloud.

After upload:
- Open the **Actions** tab.
- Open **Build ShadowFox TV Fast Task Killer APK**.
- Run the workflow if it did not start automatically.
- Download the artifact named **ShadowFox-TV-Fast-Task-Killer**.
- Unzip that artifact to get `app-debug.apk`.
