package ca.shadowfoxtv.taskkiller;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.view.animation.AnimationUtils;
import android.view.animation.Animation;
import android.view.View;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final List<String> userPackages = new ArrayList<>();
    private final Set<String> protectedPackages = new HashSet<>();

    private TextView summaryText;
    private TextView modeText;
    private Button cleanButton;
    private boolean cleaning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        summaryText = findViewById(R.id.summaryText);
        modeText = findViewById(R.id.modeText);
        cleanButton = findViewById(R.id.cleanButton);
        Button rescanButton = findViewById(R.id.rescanButton);

        protectedPackages.add(getPackageName());
        protectedPackages.add("com.android.systemui");
        protectedPackages.add("com.google.android.tvlauncher");
        protectedPackages.add("com.google.android.apps.tv.launcherx");
        protectedPackages.add("com.google.android.tv.remote.service");
        protectedPackages.add("com.android.settings");

        cleanButton.setOnClickListener(v -> cleanNow());
        rescanButton.setOnClickListener(v -> scanApps());

        // No root probe at startup, so customers are not bothered by a root prompt.
        modeText.setText("Automatic mode • no setup required");
        scanApps();
        cleanButton.requestFocus();

        View root = findViewById(R.id.rootLayout);
        View header = findViewById(R.id.headerCard);
        View status = findViewById(R.id.statusCard);
        root.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_scale_in));
        header.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_scale_in));
        status.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_scale_in));
    }

    private void scanApps() {
        executor.execute(() -> {
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> installed = pm.getInstalledApplications(0);
            List<String> found = new ArrayList<>();

            for (ApplicationInfo info : installed) {
                boolean system = (info.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                boolean updatedSystem = (info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;

                if (system && !updatedSystem) continue;
                if (protectedPackages.contains(info.packageName)) continue;
                found.add(info.packageName);
            }

            runOnUiThread(() -> {
                userPackages.clear();
                userPackages.addAll(found);
                if (!cleaning) {
                    summaryText.setText(userPackages.size() + " user apps ready for cleanup");
                }
            });
        });
    }

    private void cleanNow() {
        if (cleaning) return;
        cleaning = true;
        cleanButton.setEnabled(false);
        cleanButton.setText("CLEANING…");
        summaryText.setText("Cleaning background apps…");

        final List<String> targets = new ArrayList<>(userPackages);

        executor.execute(() -> {
            boolean root = hasRootWithoutInteractiveProbe();

            int rootStopped = 0;
            int fallbackAttempted = 0;

            if (root) {
                for (String pkg : targets) {
                    if (protectedPackages.contains(pkg)) continue;
                    try {
                        Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "am force-stop " + shellQuote(pkg)});
                        if (p.waitFor() == 0) rootStopped++;
                    } catch (Exception ignored) {}
                }
            } else {
                ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                if (am != null) {
                    for (String pkg : targets) {
                        if (protectedPackages.contains(pkg)) continue;
                        try {
                            am.killBackgroundProcesses(pkg);
                            fallbackAttempted++;
                        } catch (Exception ignored) {}
                    }
                }
            }

            final boolean usedRoot = root;
            final int strongCount = rootStopped;
            final int fallbackCount = fallbackAttempted;

            runOnUiThread(() -> {
                cleaning = false;
                cleanButton.setEnabled(true);
                cleanButton.setText(R.string.clean_now);
                cleanButton.startAnimation(AnimationUtils.loadAnimation(this, R.anim.button_pop));

                if (usedRoot) {
                    modeText.setText("Deep clean mode");
                    modeText.setTextColor(Color.rgb(54, 226, 122));
                    summaryText.setText("Cleanup complete • " + strongCount + " apps force-stopped");
                } else {
                    modeText.setText("Standard cleanup mode");
                    modeText.setTextColor(Color.rgb(175, 195, 216));
                    summaryText.setText("Cleanup complete");
                    Toast.makeText(
                            this,
                            "Background cleanup requested for " + fallbackCount + " apps.",
                            Toast.LENGTH_SHORT
                    ).show();
                }

                scanApps();
                cleanButton.requestFocus();
            });
        });
    }

    /**
     * Avoids launching an interactive "su" process during app startup.
     * This checks for common su binaries first, then performs a quick id test only
     * when su appears to exist. A root manager may still prompt the first time
     * CLEAN NOW is used; once the user grants permanent access, future cleans are one tap.
     */
    private boolean hasRootWithoutInteractiveProbe() {
        String[] candidates = {
                "/system/bin/su",
                "/system/xbin/su",
                "/sbin/su",
                "/su/bin/su",
                "/data/adb/magisk/su"
        };

        boolean suExists = false;
        for (String p : candidates) {
            if (new java.io.File(p).exists()) {
                suExists = true;
                break;
            }
        }
        if (!suExists) return false;

        Process p = null;
        try {
            p = Runtime.getRuntime().exec(new String[]{"su", "-c", "id"});
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = r.readLine();
            int code = p.waitFor();
            return code == 0 && line != null && line.contains("uid=0");
        } catch (Exception e) {
            return false;
        } finally {
            if (p != null) p.destroy();
        }
    }

    private String shellQuote(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }

    @Override
    protected void onDestroy() {
        executor.shutdown();
        super.onDestroy();
    }
}
