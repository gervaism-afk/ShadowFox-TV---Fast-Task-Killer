# ShadowFox TV Fast Task Killer v3

Premium polished release.

- Custom branded Android icon
- Custom Android TV/Fire TV banner
- Branded splash screen
- Premium dark UI
- Remote/D-pad focus glow
- Startup and completion animations
- One-click CLEAN NOW preserved
- Version 3.0.0

## v3.0.1 icon correction
- Launcher icon uses the actual supplied ShadowFox TV logo.
- Removed the substitute adaptive/vector fox icon.
