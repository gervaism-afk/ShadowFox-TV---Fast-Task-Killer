# ShadowFox TV Fast Task Killer v3

Premium polished release.

- Custom branded Android icon
- Custom Android TV/Fire TV banner
- Branded splash screen
- Premium dark UI
- Remote/D-pad focus glow
- Startup and completion animations
- One-click CLEAN NOW preserved
- Version 3.0.0

## v3.0.1 icon correction
- Launcher icon uses the actual supplied ShadowFox TV logo.
- Removed the substitute adaptive/vector fox icon.

## v3.0.2 splash alignment fix
- Splash logo, FAST TASK KILLER text, and website are now separate Android layout elements.
- All splash elements use true center alignment across TV resolutions and aspect ratios.
- Working cleanup code and real-logo launcher icon remain unchanged.

## v3.0.3 cleanup metrics
- Results now show apps cleaned, measured available-RAM increase, and measured free-storage increase.
- Rooted devices also run Android package-manager cache trimming during CLEAN NOW.
- Cache trimming does not intentionally clear app data, account logins, settings, downloads, or user files.
- Non-root devices show storage reclaimed based only on measurable storage change; no fake storage number is reported.

## v3.0.4 non-root release
- Removed all root checks and root commands.
- CLEAN NOW never requests superuser/root access.
- Uses Android's standard background-process cleanup only.
- RAM recovered is still measured before/after cleanup.
- Storage clearing is not attempted because Android restricts third-party apps from clearing other apps' caches without elevated privileges.
